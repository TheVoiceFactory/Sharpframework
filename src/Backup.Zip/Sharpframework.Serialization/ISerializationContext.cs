﻿using Sharpframework.Core;


namespace Sharpframework.Serialization
{
    public interface ISerializationContext
        : IContext
    {
    } // End of Interface ISerializationContext
} // End of Namespace Sharpframework.Serialization
