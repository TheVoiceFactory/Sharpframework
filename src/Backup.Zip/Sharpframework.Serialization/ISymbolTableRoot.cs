﻿
namespace Sharpframework.Serialization
{
    public interface ISymbolTableRoot
        : ISymbolTableNode
    {
    } // End of Interface ISymbolTableRoot
} // End of Namespace Sharpframework.Serialization
