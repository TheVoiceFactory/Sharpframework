﻿
namespace Sharpframework.Serialization
{
    public interface ISymbolTableItem
    {
    } // End of Interface ISymbolTableItem
} // End of Namespace Sharpframework.Serialization
