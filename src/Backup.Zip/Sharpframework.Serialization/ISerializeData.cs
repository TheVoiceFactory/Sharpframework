﻿using System;


namespace Sharpframework.Serialization
{
    public interface ISerializeData
    {
        Boolean SerializeData { get; set; }
    } // End of Interface ISerializeData
} // End of Namespace Sharpframework.Serialization
