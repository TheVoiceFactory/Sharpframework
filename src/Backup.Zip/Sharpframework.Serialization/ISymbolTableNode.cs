﻿
namespace Sharpframework.Serialization
{
    public interface ISymbolTableNode
        : ISymbolTableItem
    {
    } // End of Interface ISymbolTableNode
} // End of Namespace Sharpframework.Serialization
