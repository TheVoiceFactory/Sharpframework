using System;
using System.Linq;
using System.Collections.Generic;

namespace Sharpframework.Propagation
{
    public class PingMsg : SystemCommand<PingMsg, string>
    {
    }
}