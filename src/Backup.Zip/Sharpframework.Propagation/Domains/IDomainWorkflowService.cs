﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sharpframework.Propagation.Domains
{
    public interface IDomainWorkflowService:IDomainService  { }
    public abstract class DomainWorkflowService : IDomainWorkflowService
    {

    }
}
