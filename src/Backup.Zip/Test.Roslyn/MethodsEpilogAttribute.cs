﻿using System;


namespace Test.Roslyn
{
    public class MethodsEpilogAttribute : Attribute
    {
        public MethodsEpilogAttribute ( String epilogMethodName ) { }
    }
}
