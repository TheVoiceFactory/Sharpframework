﻿using System;


namespace Test.Roslyn
{
    public class MethodsPrologAttribute : Attribute
    {
        public MethodsPrologAttribute ( String prologMethodName ) { }
    }
}
