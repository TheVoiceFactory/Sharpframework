﻿using System;


namespace Sharpframework.Serialization.ValueDom
{
    public interface IValueItemObjectValueBinder
    {
        Object BoundObjectValue { get; set; }
    } // End of Interface IValueItemObjectValueBinder
} // End of Namespace Sharpframework.Serialization.ValueDom
