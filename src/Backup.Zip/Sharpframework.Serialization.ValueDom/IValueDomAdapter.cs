﻿namespace Sharpframework.Serialization.ValueDom
{
    using Sharpframework.Serialization;


    public interface IValueDomAdapter
        : ISymbolTableAdapter<IValueUnit>
    {
    } // End of Interface IValueDomAdapter
} // End of Namespace Sharpframework.Serialization.ValueDom
