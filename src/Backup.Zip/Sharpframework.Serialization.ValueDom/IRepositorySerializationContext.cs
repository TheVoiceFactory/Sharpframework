﻿
namespace Sharpframework.Serialization.ValueDom
{
    public interface IRepositorySerializationContext
        : IHierarchicalMetadataSerializationContext
    {
    } // End of Interface IRepositorySerializationContext
} // End of Namespace Sharpframework.Serialization.ValueDom
