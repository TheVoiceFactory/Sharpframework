﻿using System;


namespace Sharpframework.Core
{
    public interface INameProvider
    {
        String Name { get; }
    } // End of Interface INameProvider
} // End of Namespace Sharpframework.Core
