
namespace Sharpframework.Core
{
    public interface IContext
    { }
} // End of Namespace Sharpframework.Core