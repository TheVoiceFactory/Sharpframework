﻿
namespace Sharpframework.Core
{
    public interface ICodeProvider<CodeType>
    {
        CodeType Code { get; }
    } // End of Interface ICodeProvider<...>
} // End of Namespace Sharpframework.Core
