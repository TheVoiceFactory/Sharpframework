
namespace Sharpframework.Core
{
    public interface IOffsetProvider<OffsetType>
    {
        OffsetType Offset { get; }
    } // End of Interface IOffsetProvider<...>
} // End of Namespace Sharpframework.Core
