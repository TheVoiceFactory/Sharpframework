﻿
namespace Sharpframework.EntityModel
{
    public interface IEntityContract
        : ICompositedIdContract
        , IUid
    {
    } // End of Interface IEntityContract
} // End of Namespace Sharpframework.EntityModel
