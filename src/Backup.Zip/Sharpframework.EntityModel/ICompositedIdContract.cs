﻿
namespace Sharpframework.EntityModel
{
    public interface ICompositedIdContract
        : IValueObjectContract
    {
    } // End of Interface ICompositedIdContract
} // End of Namespace Sharpframework.EntityModel
