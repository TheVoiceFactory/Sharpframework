﻿
namespace Sharpframework.Propagation.Facts
{
    public interface IFact
    {
    }
}
