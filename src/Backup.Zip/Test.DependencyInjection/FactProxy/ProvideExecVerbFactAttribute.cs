﻿using System;


namespace Sharpframework.Propagation.Facts
{
    [ AttributeUsage (AttributeTargets.Method ) ]
    public class ProvideExecVerbFactAttribute : Attribute
    {
    }
}
