﻿
namespace Sharpframework.Roslyn.DynamicProxy
{
    public enum MemberType
    {
        Method,
        PropertyGet,
        PropertySet
    }
}
