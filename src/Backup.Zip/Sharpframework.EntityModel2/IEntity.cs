﻿
namespace Sharpframework.EntityModel
{
    public interface IEntity
        : ICompositedId
        , IUidReference
    { }
} // End of Namespace Sharpframework.EntityModel
