﻿
namespace Sharpframework.EntityModel
{
    public interface ICompositedIdSerializationContract
        : IValueObjectSerializationContract
    {
    } // End of Interface ICompositedIdSerializationContract
} // End of Namespace Sharpframework.EntityModel
