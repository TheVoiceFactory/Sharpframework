﻿using System;


namespace Sharpframework.EntityModel
{
    public interface IContractBase
    {
    } // End of Interface IContractBase
} // End of Namespace Sharpframework.Domains.Shared.Framework
