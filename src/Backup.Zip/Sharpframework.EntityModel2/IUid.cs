﻿
namespace Sharpframework.EntityModel
{
    public interface IUid
        : IGuidProvider
        , IVersionProvider
    {
    } // End of Interface IUid
} // End of Namespace Sharpframework.Domains.Shared.Framework
