﻿using System;


namespace Sharpframework.EntityModel
{
    public interface IVersionProvider
    {
        String Version { get; }
    } // End of Interface IVersionProvider
} // End of Namespace Sharpframework.Domains.Shared.Framework
